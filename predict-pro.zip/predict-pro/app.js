// PREDICT PRO — prototype pédagogique.
// Les équipes et paramètres ci-dessous sont fictifs. Remplacer par une API licenciée avant toute publication.
const matches = [
  {id:1, league:"Europe", competition:"Ligue européenne · Démo", home:"Étoile FC", away:"Union Sport", homeCode:"EF", awayCode:"US", date:"Aujourd'hui · 18:00", lambdaHome:1.65, lambdaAway:1.05},
  {id:2, league:"Afrique", competition:"Championnat africain · Démo", home:"Abidjan AC", away:"Lagune FC", homeCode:"AA", awayCode:"LF", date:"Aujourd'hui · 20:00", lambdaHome:1.35, lambdaAway:0.85},
  {id:3, league:"Europe", competition:"Coupe européenne · Démo", home:"Royal Nord", away:"Dynamo Sud", homeCode:"RN", awayCode:"DS", date:"Demain · 17:30", lambdaHome:1.4, lambdaAway:1.3},
  {id:4, league:"International", competition:"Match international · Démo", home:"Sélection A", away:"Sélection B", homeCode:"SA", awayCode:"SB", date:"Demain · 19:00", lambdaHome:1.8, lambdaAway:0.9},
  {id:5, league:"Afrique", competition:"Ligue régionale · Démo", home:"Savane FC", away:"Côte Étoile", homeCode:"SF", awayCode:"CE", date:"Samedi · 16:00", lambdaHome:1.1, lambdaAway:1.15},
  {id:6, league:"Europe", competition:"Ligue européenne · Démo", home:"Olympique Bleu", away:"Athletic Vert", homeCode:"OB", awayCode:"AV", date:"Samedi · 21:00", lambdaHome:1.75, lambdaAway:1.2}
];
let activeFilter = "Tous";

function poisson(k, lambda) {
  let factorial = 1;
  for (let i = 2; i <= k; i++) factorial *= i;
  return Math.exp(-lambda) * Math.pow(lambda, k) / factorial;
}
function calculate(m) {
  const scores = [];
  let homeWin = 0, draw = 0, awayWin = 0;
  for (let h = 0; h <= 8; h++) {
    for (let a = 0; a <= 8; a++) {
      const p = poisson(h, m.lambdaHome) * poisson(a, m.lambdaAway);
      scores.push({home:h, away:a, p});
      if (h > a) homeWin += p;
      else if (h === a) draw += p;
      else awayWin += p;
    }
  }
  scores.sort((x,y) => y.p - x.p);
  return {scores, outcomes:[{label:"Victoire domicile",p:homeWin},{label:"Match nul",p:draw},{label:"Victoire extérieur",p:awayWin}]};
}
function pct(n) { return `${Math.round(n * 100)}%`; }
function renderMatches() {
  const query = document.getElementById("searchInput").value.trim().toLocaleLowerCase("fr");
  const shown = matches.filter(m => (activeFilter === "Tous" || m.league === activeFilter) &&
    `${m.home} ${m.away} ${m.competition}`.toLocaleLowerCase("fr").includes(query));
  const grid = document.getElementById("matchGrid");
  grid.innerHTML = "";
  document.getElementById("emptyState").classList.toggle("hidden", shown.length !== 0);
  shown.forEach(m => {
    const result = calculate(m);
    const best = result.scores[0];
    const card = document.createElement("article");
    card.className = "match-card";
    card.innerHTML = `
      <div class="match-meta"><span class="league-tag">${m.league}</span><span>${m.date}</span></div>
      <div class="match-teams">
        <div class="match-team"><span class="team-symbol">${m.homeCode}</span>${m.home}</div>
        <span class="vs">VS</span>
        <div class="match-team"><span class="team-symbol">${m.awayCode}</span>${m.away}</div>
      </div>
      <div class="prediction-preview"><span>Score statistique principal</span><strong>${best.home} — ${best.away}</strong></div>
      <div class="card-bottom"><small>Paramètres de démonstration</small><button class="analyze-btn">Analyser →</button></div>`;
    card.querySelector("button").addEventListener("click", () => openPrediction(m));
    grid.appendChild(card);
  });
}
function openPrediction(m) {
  const r = calculate(m);
  const best = r.scores[0];
  document.getElementById("dialogTitle").textContent = `${m.home} – ${m.away}`;
  document.getElementById("dialogSubtitle").textContent = `${m.competition} · ${m.date}`;
  document.getElementById("bestScore").textContent = `${best.home} — ${best.away}`;
  document.getElementById("scoreProbability").textContent = `${pct(best.p)} de probabilité estimée dans cette simulation`;
  document.getElementById("altScores").innerHTML = r.scores.slice(1,4).map(s =>
    `<div class="alt-score"><strong>${s.home} — ${s.away}</strong><span>${pct(s.p)}</span></div>`).join("");
  document.getElementById("outcomeProbabilities").innerHTML = r.outcomes.map(o =>
    `<div class="outcome"><span>${o.label}</span><div class="bar"><i style="width:${Math.max(1,o.p*100)}%"></i></div><b>${pct(o.p)}</b></div>`).join("");
  document.getElementById("predictionDialog").showModal();
}
document.getElementById("searchInput").addEventListener("input", renderMatches);
document.querySelectorAll(".filter").forEach(btn => btn.addEventListener("click", () => {
  activeFilter = btn.dataset.filter;
  document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === btn));
  renderMatches();
}));
function notice(title, text) {
  document.getElementById("noticeTitle").textContent = title;
  document.getElementById("noticeText").textContent = text;
  document.getElementById("noticeDialog").showModal();
}
document.getElementById("signinBtn").addEventListener("click", () => notice("Connexion à venir", "La connexion et les comptes utilisateurs ne sont pas encore activés dans cette version. Ils nécessiteront un service d'authentification sécurisé."));
document.querySelectorAll(".planBtn").forEach(btn => btn.addEventListener("click", () => notice("Abonnement " + btn.dataset.plan, "Le paiement n'est pas activé. Avant de recevoir de l'argent, connecte un prestataire de paiement adapté, vérifie les notifications côté serveur et teste les remboursements."));
document.getElementById("noticeOk").addEventListener("click", () => document.getElementById("noticeDialog").close());
renderMatches();
