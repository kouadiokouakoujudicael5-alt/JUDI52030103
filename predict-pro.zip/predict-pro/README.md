# PREDICT PRO — prototype web

Prototype responsive en français pour une application de prédiction de scores de football.

## Ce qui fonctionne déjà
- Affichage des matchs fictifs.
- Recherche d'équipes.
- Filtre Europe / Afrique / International.
- Calcul local de probabilités illustratives avec une loi de Poisson.
- Affichage du score le plus probable, de trois scores alternatifs et des probabilités 1N2.
- Présentation des formules d'abonnement (sans paiement réel).

## Important
Les équipes, calendriers et paramètres de buts sont fictifs. Ce projet ne récupère pas de données sportives en direct, ne possède pas de comptes utilisateurs et n'encaisse aucun paiement. Ne le présente pas comme un service de prédiction réelle avant d'avoir branché une source de données autorisée et testé le modèle.

## Démarrage — méthode la plus simple
1. Décompresse `predict-pro.zip`.
2. Ouvre le dossier `predict-pro`.
3. Double-clique sur `index.html` pour ouvrir le site dans ton navigateur.
4. Essaie les filtres, la recherche, puis clique sur « Analyser » pour voir les calculs.

Le prototype peut fonctionner localement sans installer de logiciel ni payer d'hébergement.

## Publication en ligne
Pour une démo, tu peux déployer les trois fichiers (`index.html`, `style.css`, `app.js`) sur un hébergeur statique comme Cloudflare Pages, Netlify ou GitHub Pages. Vérifie leurs conditions et les étapes actuelles de déploiement avant de publier.

## Prochaines étapes pour une vraie version
1. Choisir une API football et vérifier ses compétitions, quotas, historique et licence.
2. Déplacer les appels à l'API et les clés secrètes côté serveur.
3. Construire un backend Python/FastAPI et une base PostgreSQL/Supabase.
4. Entraîner et évaluer le modèle sur des données historiques, avec séparation chronologique des données.
5. Ajouter une authentification et des règles d'accès aux abonnements.
6. Intégrer un prestataire de paiement prenant en charge les moyens de paiement visés. Vérifier les paiements via des webhooks côté serveur. Ne jamais collecter les numéros de carte soi-même.
7. Tester sécurité, confidentialité, exactitude des données, annulations et remboursements.

## Structure
- `index.html` : contenu et structure
- `style.css` : design responsive
- `app.js` : matchs de démonstration et calculs statistiques
